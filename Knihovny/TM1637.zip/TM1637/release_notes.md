- V1.2.0
  * Add support for negative numbers
  * Add support for hexadeciaml number
  * Bump default bit delay to 100us, make it adjustable
  * Add Arduino library metadata
  
- V1.1.0
  * Add support for decimal points/colon
  * Minor fixes
  
- V1.0.0
  * Initial release

